import React, { useState } from "react";

import ProfileCollection from "./components/ProfileCollection";


const App = () => {
  const [profiles, setProfiles] = useState(initialProfiles);
  const [filteredProfiles, setFilteredProfiles] = useState(profiles);

  
  const filterProfiles = (criteria) => {
    const filtered = profiles.filter((profile) => {
      
      return (
        (!criteria.name || profile.name.toLowerCase().includes(criteria.name.toLowerCase())) &&
        (!criteria.location || profile.address.toLowerCase().includes(criteria.location.toLowerCase()))
        
      );
    });
    setFilteredProfiles(filtered);
  };

  
  
  return (
    <div className="App">
      <h1>Profile Collection</h1>
      <AdminPanel addProfile={profiles} editProfile={setProfiles} deleteProfile={profiles} />
      <FilterPanel filterProfiles={filterProfiles} />
      <ProfileCollection profiles={filteredProfiles} />
    </div>
  );
};

export default App;